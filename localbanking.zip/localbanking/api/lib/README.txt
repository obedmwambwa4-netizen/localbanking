FPDF Library — Required for PDF statements
===========================================
1. Go to: http://www.fpdf.org
2. Click "Download"
3. Extract the zip
4. Copy fpdf.php into this folder: api/lib/fpdf.php

That's all you need — just the single fpdf.php file.
