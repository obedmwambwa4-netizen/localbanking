<?php
// =============================================
//  VCBI — Members API   (api/members.php)
//  GET    members.php            → all members
//  GET    members.php?id=3       → one member
//  POST   members.php            → register member
//  PUT    members.php?id=3       → update member
//  DELETE members.php?id=3       → delete member (only if no history)
// =============================================
require_once __DIR__ . '/config.php';
apiHeaders();

$db     = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$body   = json_decode(file_get_contents('php://input'), true);
if (!is_array($body)) $body = $_POST;

$id = (int)($_GET['id'] ?? $body['id'] ?? 0);

// read a field under several possible names (snake_case or camelCase)
function field(array $b, array $names, $default = '') {
    foreach ($names as $n) {
        if (isset($b[$n]) && $b[$n] !== '') return is_string($b[$n]) ? trim($b[$n]) : $b[$n];
    }
    return $default;
}

if ($method === 'GET') {
    if ($id) {
        $q = $db->prepare('SELECT * FROM members WHERE id = ?');
        $q->execute([$id]);
        $row = $q->fetch();
        if (!$row) error('Member not found', 404);
        respond($row);
    }
    respond($db->query('SELECT * FROM members ORDER BY id ASC')->fetchAll());
}

if ($method === 'POST') {
    $name   = field($body, ['name', 'full_name', 'fullName']);
    $phone  = field($body, ['phone', 'phone_number', 'phoneNumber']);
    $nrc    = field($body, ['national_id', 'nationalId', 'nrc']);
    $kin    = field($body, ['next_of_kin', 'nextOfKin', 'kin']);
    $joined = field($body, ['join_date', 'joinDate', 'joined_date'], date('Y-m-d'));
    $status = field($body, ['status'], 'active');

    if ($name === '')  error('Member name is required');
    if ($phone === '') error('Phone number is required');

    $dup = $db->prepare("SELECT id FROM members WHERE phone = ? OR (national_id <> '' AND national_id = ?) LIMIT 1");
    $dup->execute([$phone, $nrc]);
    if ($dup->fetch()) error('A member with this phone number or NRC already exists', 409);

    $db->prepare('INSERT INTO members (name, national_id, phone, next_of_kin, join_date, status, savings)
                  VALUES (?, ?, ?, ?, ?, ?, 0.00)')
       ->execute([$name, $nrc, $phone, $kin ?: null, $joined, $status]);

    $q = $db->prepare('SELECT * FROM members WHERE id = ?');
    $q->execute([(int)$db->lastInsertId()]);
    respond($q->fetch(), 201);
}

if ($method === 'PUT' || $method === 'PATCH') {
    if (!$id) error('Member id is required');
    $q = $db->prepare('SELECT * FROM members WHERE id = ?');
    $q->execute([$id]);
    $cur = $q->fetch();
    if (!$cur) error('Member not found', 404);

    $name   = field($body, ['name', 'full_name', 'fullName'], $cur['name']);
    $phone  = field($body, ['phone', 'phone_number', 'phoneNumber'], $cur['phone']);
    $nrc    = field($body, ['national_id', 'nationalId', 'nrc'], $cur['national_id']);
    $kin    = field($body, ['next_of_kin', 'nextOfKin', 'kin'], $cur['next_of_kin']);
    $joined = field($body, ['join_date', 'joinDate', 'joined_date'], $cur['join_date']);
    $status = field($body, ['status'], $cur['status']);

    $db->prepare('UPDATE members SET name=?, national_id=?, phone=?, next_of_kin=?, join_date=?, status=? WHERE id=?')
       ->execute([$name, $nrc, $phone, $kin ?: null, $joined, $status, $id]);

    $q->execute([$id]);
    respond($q->fetch());
}

if ($method === 'DELETE') {
    if (!$id) error('Member id is required');
    foreach (['deposits', 'loans', 'repayments'] as $t) {
        $c = $db->prepare("SELECT COUNT(*) FROM $t WHERE member_id = ?");
        $c->execute([$id]);
        if ((int)$c->fetchColumn() > 0) {
            error('This member has transaction history and cannot be deleted. Set the status to inactive instead.', 409);
        }
    }
    $db->prepare('DELETE FROM members WHERE id = ?')->execute([$id]);
    respond(['success' => true, 'deleted' => $id]);
}

error('Method not allowed', 405);
